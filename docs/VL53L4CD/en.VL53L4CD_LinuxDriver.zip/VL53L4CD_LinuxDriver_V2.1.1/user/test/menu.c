/*******************************************************************************
Copyright (C) 2021, STMicroelectronics International N.V.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of STMicroelectronics nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
NON-INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS ARE DISCLAIMED.
IN NO EVENT SHALL STMICROELECTRONICS INTERNATIONAL N.V. BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
********************************************************************************/

#include <unistd.h>
#include <signal.h>
#include <dlfcn.h>

#include <stdio.h>
#include <string.h>

#include "VL53L4CD_api.h"

#include "examples.h"

int exit_main_loop = 0;

void sighandler(int signal)
{
	printf("SIGNAL Handler called, signal = %d\n", signal);
	exit_main_loop  = 1;
}

int main(int argc, char ** argv)
{
	char choice[20];
	int status;
	VL53L4CD_LinuxDev LinuxDev;
	Dev_t Dev = &LinuxDev;
	VL53L4CD_Version_t TOF_SW_Version;

	/*********************************/
	/*   Power on sensor and init    */
	/*********************************/

	/* Initialize channel com */
	status = VL53L4CD_comms_init(Dev);
	if(status)
	{
		printf("VL53L4CD comms init failed\n");
		return -1;
	}
	
	status = VL53L4CD_GetSWVersion(&TOF_SW_Version);
	printf("Starting examples of VL53L4CD driver (version %u.%u.%u.%u)\n",
		TOF_SW_Version.major,
		TOF_SW_Version.minor,
		TOF_SW_Version.build,
		TOF_SW_Version.revision);

	do {
		printf("----------------------------------------------------------------------------------------------------------\n");
		printf(" VL53L4CD uld driver test example menu \n");
		printf(" ------------------ Ranging menu ------------------\n");
		printf(" 1 : basic ranging\n");
		printf(" 2 : low power\n");
		printf(" 3 : high accuracy\n");
		printf(" 4 : fast ranging\n");
		printf(" 5 : calibrate offset and Xatlk\n");
		printf(" 6 : detection thresholds - need to catch GPIO1 interrupt for this example\n");
		printf(" 7 : exit\n");
		printf("----------------------------------------------------------------------------------------------------------\n");

		printf("Your choice ?\n ");
		scanf("%s", choice);

		if (strcmp(choice, "1") == 0) {
			printf("Starting Test 1\n");
			status = example1(Dev);
			printf("\n");
		}
		else if (strcmp(choice, "2") == 0) {
			printf("Starting Test 2\n");
			status = example2(Dev);
			printf("\n");
		}
		else if (strcmp(choice, "3") == 0) {
			printf("Starting Test 3\n");
			status = example3(Dev);
			printf("\n");
		}
		else if (strcmp(choice, "4") == 0) {
			printf("Starting Test 4\n");
			status = example4(Dev);
			printf("\n");
		}
		else if (strcmp(choice, "5") == 0) {
			printf("Starting Test 5\n");
			status = example5(Dev);
			printf("\n");
		}
		else if (strcmp(choice, "6") == 0) {
			printf("Starting Test 6\n");
			status = example6(Dev);
			printf("\n");
		}
		else if (strcmp(choice, "7") == 0){
			exit_main_loop = 1;
		}
		
		else{
			printf("Invalid choice\n");
		}

	} while (!exit_main_loop);

	VL53L4CD_comms_close(Dev);

	return 0;
}
